import React from "react";

const Welcome = () => {
  return (
    <div className="container">
      <div className="py-4">
        <h1>Welcome </h1>
        <p className="lead">
          This is CRUD project.
          Here you can view edit and delete user list
        </p>   
        
        
      </div>
    </div>
  );
};

export default Welcome;
